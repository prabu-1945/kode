# KantinKuApp — Pembeli dan Penjual (terhubung)

## Menjalankan aplikasi
Butuh JDK 11 atau lebih baru. Jalankan dari folder `KantinKuApp`.

**Windows (PowerShell):**
```powershell
New-Item -ItemType Directory -Force -Path out | Out-Null
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java -Path .\src | ForEach-Object { $_.FullName })
java -cp "out;src" Main
```

**Linux / macOS:**
```bash
mkdir -p out
javac -encoding UTF-8 -d out $(find src -name '*.java')
java -cp "out:src" Main
```

Perintah `Main` menjalankan aplikasi **Pembeli**. Untuk menjalankan aplikasi **Penjual** secara terpisah, gunakan `MainPenjual`:

**Windows (PowerShell):**
```powershell
java -cp "out;src" MainPenjual
```

**Linux / macOS:**
```bash
java -cp "out:src" MainPenjual
```

`src` ikut di classpath supaya gambar menu di `src/images` terbaca. Pembeli dan penjual dapat dijalankan sebagai program terpisah di komputer yang sama.

## Alur pesanan (pembeli → penjual → pembeli)
1. **Pembeli** memilih menu → keranjang → pembayaran (QRIS / Transfer VA / Tunai) → konfirmasi.
   Pesanan langsung tersimpan dengan status `Menunggu konfirmasi` dan nomor unik (`#ORD-001`, `#ORD-002`, ...).
2. **Penjual** (login ke dashboard) melihat pesanan masuk otomatis, paling baru di atas.
   Tekan **Setujui / Konfirmasi pesanan** → status `Diproses`, lalu **Ubah ke Siap Diambil**, lalu **Ubah ke Selesai**.
3. **Pembeli** membuka tab **Pesanan Saya**: status berubah sendiri (tanpa pindah tab) menjadi
   `Telah dikonfirmasi · Sedang diproses` → `Siap diambil` → `Pesanan selesai`.
   Pesanan yang belum selesai ada di **Pesanan Aktif**, yang selesai pindah ke **Riwayat Pesanan**.

## Alur menu (penjual → pembeli)
Menu yang ditambah / diedit / disembunyikan / dihapus penjual langsung berubah di halaman **Menu** pembeli
(dicek setiap 1,5 detik). Katalog awal penjual sama dengan menu bawaan pembeli.

## Penyimpanan data
Folder `~/.kantinku-desktop` (Windows: `%USERPROFILE%\.kantinku-desktop`):
- `orders.tsv` pesanan (dipakai bersama pembeli & penjual, dikunci saat ditulis)
- `orders-pembeli.txt` daftar nomor pesanan milik pembeli di komputer ini
- `menus.tsv` katalog menu penjual
- `accounts.tsv` akun penjual (password di-hash)

Pembeli dan penjual boleh dijalankan sebagai dua program terpisah di komputer yang sama; datanya tetap sinkron.
Untuk mulai dari nol, tutup aplikasi lalu hapus folder tersebut.

## Revisi terbaru
- **Data pembeli tersimpan** (`buyers.tsv`): nama dan nomor HP (opsional) terisi otomatis di halaman Pembayaran untuk pesanan berikutnya. Tombol **Ganti pembeli** ada di tab Pesanan Saya.
- **Pesanan orang yang sama tersimpan**: tab Pesanan Saya menampilkan semua pesanan dengan nama pembeli yang sama (huruf besar/kecil diabaikan), juga setelah aplikasi ditutup lalu dibuka lagi.
- **Keranjang**: tiap baris punya tombol **Edit** (ubah jumlah, dibatasi stok) dan **Hapus**.
- **Struk pembelian**: muncul setelah pesanan dikonfirmasi; bisa **Simpan struk** (.txt), **Cetak**, dan dibuka lagi lewat **Lihat struk** di Pesanan Saya. Salinan otomatis ada di `~/.kantinku-desktop/struk/`.
- **Stok menu**: penjual mengisi stok di Tambah/Edit menu. Pembeli melihat sisa stok di kartu menu; menu habis tidak bisa dipesan. Stok berkurang saat pesanan dikonfirmasi pembeli dan langsung terlihat di dashboard penjual.
- Judul halaman rata kiri; tombol **Tambah menu** sebaris dengan **Cari nama menu**; tombol konfirmasi pesanan penjual sebaris dengan detail pesanan; pesan konfirmasi dibuat satu baris.
- Format berkas bertambah kolom (`orders.tsv`: HP dan waktu; `menus.tsv`: stok). Berkas lama tetap terbaca.

## Revisi tahap 2 (penjual)
- Halaman login: kartu menyesuaikan tinggi isi sehingga tombol tidak terpotong setelah registrasi; judul dan teks kecil rata tengah; "Lupa Password?" di tengah; tautan popup "Kembali ke Portal Penjual" dihapus.
- Dashboard: menu "Beranda Toko" (yang memunculkan popup) dihapus; kartu pesanan tidak lagi melar penuh bila hanya ada satu pesanan.
- Tab baru **Riwayat**: pesanan berstatus Selesai (sudah diambil) pindah ke sini, lengkap dengan pencarian dan total nilai.
- Tombol Tambah menu dan Setujui/Konfirmasi pesanan kini berwarna terisi (tidak putih) di Windows.

## Yang diperbaiki dari versi sebelumnya
- Nomor pesanan tidak lagi mulai dari `#ORD-001` setiap aplikasi dibuka (dulu pesanan lama tertimpa).
- Status pesanan di pembeli diperbarui otomatis, bukan hanya saat pindah tab.
- "Pesanan Saya" hanya menampilkan pesanan yang benar-benar sudah tersimpan (dulu bisa muncul pesanan hantu bila pembayaran dibatalkan) dan menampilkan semua pesanan, bukan hanya yang terakhir.
- Menu pembeli ikut berubah saat penjual mengubah katalog, termasuk bila semua menu disembunyikan.
- Menutup satu jendela tidak lagi menutup seluruh aplikasi; aplikasi berhenti setelah semua jendela tertutup.
- Penulisan pesanan aman dari tabrakan antar-program (file lock) dan nomor pesanan ganda otomatis dibetulkan.
- Metode transfer sekarang mencatat banknya (mis. `Transfer Bank (BCA)`).
