import view.KantinKuPembeliView;
import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UIManager.put("OptionPane.messageFont", new Font("SansSerif", Font.PLAIN, 14));
            KantinKuPembeliView app = new KantinKuPembeliView();
            app.setVisible(true);
        });
    }
}
