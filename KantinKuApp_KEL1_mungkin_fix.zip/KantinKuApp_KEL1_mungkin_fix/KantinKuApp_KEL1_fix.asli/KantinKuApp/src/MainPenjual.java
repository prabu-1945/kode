import id.kantinku.desktop.KantinKuDesktopApp;

public class MainPenjual {
    public static void main(String[] args) {
        KantinKuDesktopApp.launch();
    }
}
