package service;

import model.Menu;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Akses katalog menu (menus.tsv) yang dipakai bersama pembeli dan penjual, khususnya untuk stok.
 * Setiap perubahan dilakukan di dalam kunci berkas, sehingga stok tidak saling menimpa
 * walau pembeli dan penjual berjalan sebagai dua program terpisah.
 *
 * Format baris (semua kolom teks di-Base64): id, nama, deskripsi, harga, kategori, gambar, aktif, stok.
 * Berkas lama tanpa kolom stok tetap bisa dibaca (stok awal {@link Menu#STOK_AWAL}).
 */
public final class KatalogBersama {
    private static final Path FOLDER = Path.of(System.getProperty("user.home"), ".kantinku-desktop");
    private static final Path FILE = FOLDER.resolve("menus.tsv");
    private static final Path FILE_LOCK = FOLDER.resolve("menus.lock");

    private KatalogBersama() {}

    public interface Pekerjaan<T> {
        T jalankan() throws IOException;
    }

    public static Path berkas() {
        return FILE;
    }

    /** Penanda perubahan berkas katalog (untuk mendeteksi perubahan menu/stok). */
    public static long penanda() {
        try {
            return Files.exists(FILE) ? Files.getLastModifiedTime(FILE).toMillis() * 31 + Files.size(FILE) : -1;
        } catch (IOException e) {
            return -1;
        }
    }

    public static <T> T dalamKunci(Pekerjaan<T> kerja) throws IOException {
        Files.createDirectories(FOLDER);
        try (RandomAccessFile raf = new RandomAccessFile(FILE_LOCK.toFile(), "rw");
             FileChannel channel = raf.getChannel();
             FileLock lock = channel.lock()) {
            return kerja.jalankan();
        }
    }

    /** Membuat berkas katalog dari daftar menu bawaan bila belum ada, agar stok bisa tercatat. */
    public static void buatJikaBelumAda(List<Menu> daftar) throws IOException {
        dalamKunci(() -> {
            if (Files.exists(FILE)) return null;
            List<String> lines = new ArrayList<>();
            for (Menu m : daftar) {
                String id = m.getNama().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-");
                lines.add(String.join("\t", enc(id), enc(m.getNama()), enc(m.getDeskripsi()),
                        Integer.toString(m.getHarga()), enc(m.getKategori()), enc(m.getNamaGambar()),
                        "true", Integer.toString(m.getStok())));
            }
            tulis(lines);
            return null;
        });
    }

    /**
     * Mengurangi stok sekaligus untuk semua menu dalam pesanan (nama menu -> jumlah porsi).
     * Semua-atau-tidak-sama-sekali: bila ada satu menu yang stoknya kurang, tidak ada yang dikurangi.
     *
     * @return null bila berhasil, atau pesan alasan bila gagal.
     */
    public static String kurangiStok(Map<String, Integer> permintaan) throws IOException {
        return dalamKunci(() -> {
            if (!Files.exists(FILE)) return "Katalog menu tidak ditemukan.";
            List<String> lines = new ArrayList<>(Files.readAllLines(FILE, StandardCharsets.UTF_8));
            // cek dulu semuanya
            for (Map.Entry<String, Integer> e : permintaan.entrySet()) {
                int idx = cariBaris(lines, e.getKey());
                if (idx < 0) return "Menu \"" + e.getKey() + "\" sudah tidak tersedia.";
                String[] f = lines.get(idx).split("\\t", -1);
                if (!Boolean.parseBoolean(f[6])) return "Menu \"" + e.getKey() + "\" sedang tidak dijual.";
                int stok = stokDari(f);
                if (stok < e.getValue()) {
                    return stok <= 0 ? "Stok \"" + e.getKey() + "\" sudah habis."
                            : "Stok \"" + e.getKey() + "\" tinggal " + stok + " porsi.";
                }
            }
            for (Map.Entry<String, Integer> e : permintaan.entrySet()) {
                int idx = cariBaris(lines, e.getKey());
                String[] f = lines.get(idx).split("\\t", -1);
                lines.set(idx, barisDenganStok(f, stokDari(f) - e.getValue()));
            }
            tulis(lines);
            return null;
        });
    }

    /** Mengembalikan stok (dipakai bila pesanan gagal disimpan setelah stok dikurangi). */
    public static void kembalikanStok(Map<String, Integer> permintaan) throws IOException {
        dalamKunci(() -> {
            if (!Files.exists(FILE)) return null;
            List<String> lines = new ArrayList<>(Files.readAllLines(FILE, StandardCharsets.UTF_8));
            for (Map.Entry<String, Integer> e : permintaan.entrySet()) {
                int idx = cariBaris(lines, e.getKey());
                if (idx < 0) continue;
                String[] f = lines.get(idx).split("\\t", -1);
                lines.set(idx, barisDenganStok(f, stokDari(f) + e.getValue()));
            }
            tulis(lines);
            return null;
        });
    }

    // ------------------------------------------------------------------ internal

    private static int cariBaris(List<String> lines, String namaMenu) {
        for (int i = 0; i < lines.size(); i++) {
            String[] f = lines.get(i).split("\\t", -1);
            if (f.length < 7) continue;
            try {
                if (dec(f[1]).equalsIgnoreCase(namaMenu)) return i;
            } catch (IllegalArgumentException ignored) {
                // baris rusak dilewati
            }
        }
        return -1;
    }

    private static int stokDari(String[] f) {
        if (f.length >= 8) {
            try {
                return Integer.parseInt(f[7].trim());
            } catch (NumberFormatException ignored) {
                // pakai stok awal
            }
        }
        return Menu.STOK_AWAL;
    }

    private static String barisDenganStok(String[] f, int stokBaru) {
        String[] hasil = new String[8];
        System.arraycopy(f, 0, hasil, 0, 7);
        hasil[7] = Integer.toString(Math.max(0, stokBaru));
        return String.join("\t", hasil);
    }

    private static void tulis(List<String> lines) throws IOException {
        Files.createDirectories(FOLDER);
        Path temp = Files.createTempFile(FOLDER, "menus-", ".tmp");
        try {
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    private static String enc(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));
    }

    private static String dec(String s) {
        return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8);
    }
}
